
# Kortspil – Izoizi

4-spiller React-spil med 26 kort fra 7 til Es og roterende budgiver.  
Bygget med Vite + React og klar til Netlify.

## Sådan kører du det lokalt:

```bash
npm install
npm run dev
```

## Byg til produktion

```bash
npm run build
```
